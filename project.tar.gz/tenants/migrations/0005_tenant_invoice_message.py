from django.db import migrations, models, connection


def add_invoice_message_field(apps, schema_editor):
    """Safely add invoice_message field if it doesn't already exist."""
    with connection.cursor() as cursor:
        if connection.vendor == 'sqlite':
            cursor.execute("PRAGMA table_info(tenants_tenant);")
            columns = [row[1] for row in cursor.fetchall()]
            column_exists = 'invoice_message' in columns
        else:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT 1 FROM information_schema.columns 
                    WHERE table_name = 'tenants_tenant' 
                    AND column_name = 'invoice_message'
                );
            """)
            column_exists = cursor.fetchone()[0]
    
    if not column_exists:
        # Column doesn't exist, add it
        field = models.TextField(blank=True, null=True)
        field.set_attributes_from_name('invoice_message')
        schema_editor.add_field(
            apps.get_model('tenants', 'Tenant'),
            field
        )


def reverse_add_invoice_message(apps, schema_editor):
    """Reverse: remove invoice_message field if it exists."""
    with connection.cursor() as cursor:
        if connection.vendor == 'sqlite':
            cursor.execute("PRAGMA table_info(tenants_tenant);")
            columns = [row[1] for row in cursor.fetchall()]
            column_exists = 'invoice_message' in columns
        else:
            cursor.execute("""
                SELECT EXISTS (
                    SELECT 1 FROM information_schema.columns 
                    WHERE table_name = 'tenants_tenant' 
                    AND column_name = 'invoice_message'
                );
            """)
            column_exists = cursor.fetchone()[0]
    
    if column_exists:
        schema_editor.remove_field(
            apps.get_model('tenants', 'Tenant'),
            'invoice_message'
        )


class Migration(migrations.Migration):

    dependencies = [
        ('tenants', '0004_tenant_access_key'),
    ]

    operations = [
        migrations.RunPython(add_invoice_message_field, reverse_add_invoice_message),
    ]
