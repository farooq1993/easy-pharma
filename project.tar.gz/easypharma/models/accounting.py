from django.db import models
from tenants.models import TenantAwareModel
from .purchase_invoice import Supplier, PurchaseInvoice
from .Items import Products

class SupplierLedger(TenantAwareModel):
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name='ledger_entries')
    date = models.DateField()
    transaction_type = models.CharField(max_length=50, choices=[('Purchase', 'Purchase'), ('Payment', 'Payment'), ('Return', 'Return'), ('JV', 'Journal Voucher')])
    reference_number = models.CharField(max_length=100, null=True, blank=True)
    debit = models.DecimalField(max_digits=12, decimal_places=2, default=0.00) # Payment to supplier, Return
    credit = models.DecimalField(max_digits=12, decimal_places=2, default=0.00) # Purchase from supplier
    balance = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    is_adjusted = models.BooleanField(default=False)
    remarks = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.supplier.name} - {self.transaction_type} on {self.date}"

class SupplierPayment(TenantAwareModel):
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name='payments')
    payment_date = models.DateField()
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_mode = models.CharField(max_length=50, choices=[('Cash', 'Cash'), ('Bank', 'Bank'), ('Cheque', 'Cheque')])
    reference_number = models.CharField(max_length=100, null=True, blank=True)
    payment_details = models.JSONField(null=True, blank=True) # To store bank/cheque info and adjusted invoices
    remarks = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Payment to {self.supplier.name} on {self.payment_date} - {self.amount}"

class ExpiryReturn(TenantAwareModel):
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name='expiry_returns')
    return_date = models.DateField()
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    return_details = models.JSONField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Expiry Return to {self.supplier.name} on {self.return_date}"

class ExpiryReturnItem(TenantAwareModel):
    expiry_return = models.ForeignKey(ExpiryReturn, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    batch_number = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField()
    rate = models.DecimalField(max_digits=10, decimal_places=2)
    amount = models.DecimalField(max_digits=12, decimal_places=2)

    def __str__(self):
        return f"{self.product.product_name} - {self.batch_number} (x{self.quantity})"

from easypharma.models.sales import Customer

class CustomerLedger(TenantAwareModel):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='ledger_entries')
    date = models.DateField()
    transaction_type = models.CharField(max_length=50, choices=[('Sale', 'Sale'), ('Payment', 'Payment'), ('Return', 'Return'), ('JV', 'Journal Voucher')])
    reference_number = models.CharField(max_length=100, null=True, blank=True)
    debit = models.DecimalField(max_digits=12, decimal_places=2, default=0.00) # Sale amount (receivable)
    credit = models.DecimalField(max_digits=12, decimal_places=2, default=0.00) # Payment received
    balance = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    remarks = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.customer.name} - {self.transaction_type} on {self.date}"

class CustomerPayment(TenantAwareModel):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='payments')
    payment_date = models.DateField()
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_mode = models.CharField(max_length=50, choices=[('Cash', 'Cash'), ('UPI', 'UPI'), ('Card', 'Card'), ('Bank', 'Bank')])
    reference_number = models.CharField(max_length=100, null=True, blank=True)
    payment_details = models.JSONField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Payment from {self.customer.name} on {self.payment_date} - {self.amount}"
