from django.contrib import admin
from .models import User
from easypharma.models.Items import *
from easypharma.models.purchase_invoice import (PurchaseInvoice, Supplier,
                                                PurchaseItem,OpeningStock,OpeningStockItem)
from easypharma.models.sales import SaleInvoice,PrescriptionReminder

from easypharma.models.financial_year import FinancialYear

# Register your models here.
admin.site.register(User)
admin.site.register(FinancialYear)
admin.site.register(DrugCompany)
admin.site.register(ProductType)
admin.site.register(ProductSchedule)
admin.site.register(ProductTax)
admin.site.register(ProductContent)
admin.site.register(Products)
admin.site.register(PurchaseInvoice)
admin.site.register(SaleInvoice)
admin.site.register(Supplier)
admin.site.register(PrescriptionReminder)
admin.site.register(PurchaseItem)
admin.site.register(OpeningStock)
admin.site.register(OpeningStockItem)

from easypharma.models.purchase_scan_log import PurchaseScanLog
admin.site.register(PurchaseScanLog)

